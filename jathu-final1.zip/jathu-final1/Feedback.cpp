#include "Feedback.h"
Feedback::Feedback(int ID, string fb) {
    feedbackID = ID;
    feedback = fb;
}
string Feedback::getFeedback() {
    return feedback;
}
void Feedback::displayFeedback() {
    cout << "Feedback ID: " << feedbackID << endl << "Feedback: " << feedback << endl;
}