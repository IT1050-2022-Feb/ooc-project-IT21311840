#include "UnRegisteredUser.h"
UnRegisteredUser::UnRegisteredUser(string uName, string add, string mail, int no, int ID):User(uName, add, mail, no, ID) {
}
void UnRegisteredUser::displayUnRegisteredUser() {
    cout << "Name: " << username << endl << "Address: " << address << endl << "Email: " << email << endl << "Contact No: " << contactNo << endl << "Feedback ID: " << feedbackID << endl << endl;
}