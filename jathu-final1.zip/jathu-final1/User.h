#include <iostream>
#include<cstring>
#include "Feedback.h"
using namespace std;

class User {
protected:
    string username;
    string address;
    string email;
    int contactNo;
    int  feedbackID;
public:
    User(string uname, string add, string mail, int no, int ID);
    void displayDetails();
    void giveFeedback(Feedback* f);
};