#include <iostream>
#include<cstring>
#include "User.h"
#include "Resume.h"

using namespace std;
class RegisterUser;
class Resume;

class RegisterUser : public User {
private:
    int job_id;
    Resume* r;
public:
    RegisterUser(string uName, string add, string mail, int no, int jobId, int ID);
    void addResume(Resume* r1);
    void displayRegisterDetails();
};