#include "Feedback.h"
#include "RegisteredUser.h"
#include "UnRegisteredUser.h"
int main() {

    Feedback* f = new Feedback(1, "outstanding service");
    Feedback* f1 = new Feedback(2, "quality service");
    RegisterUser* u1 = new  RegisterUser("Savi", "Batticalo", "savi@gmail.com", 764948189, 101, 1);
    Resume* r = new Resume("Savi", "personal details", "academic details", u1);
    cout << "---------------Register user---------------" << endl;
    u1->giveFeedback(f);
    u1->displayRegisterDetails();
    cout << "---------------UnRegistered user---------------" << endl;
    UnRegisteredUser* ur1 = new UnRegisteredUser("Jathu", "Vavuniya", "jathu@gmail.com", 769052508, 2);
    ur1->giveFeedback(f1);
    ur1->displayUnRegisteredUser();
    cout << "---------------Feedback---------------" << endl;
    f->displayFeedback();
    cout << endl;
    f1->displayFeedback();

    return 0;
}