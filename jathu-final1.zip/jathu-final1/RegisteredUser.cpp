#include "RegisteredUser.h"
RegisterUser::RegisterUser(string uName, string add, string mail, int no, int jobId, int ID) :User(uName, add, mail, no, ID) {
    job_id = jobId;
}
void RegisterUser::addResume(Resume* r1){
    r = r1;
}
void RegisterUser::displayRegisterDetails() {
    cout << "Name: " << username << endl << "Address: " << address << endl << "Email: " << email << endl << "Contact No: " << contactNo << endl << "Job ID : " << job_id << endl << "Feedback ID: " << feedbackID << endl;
    r->displayResumeDetails();
}