#include "User.h"
User::User(string uName, string add, string mail, int no, int ID) {
    username = uName;
    address = add;
    email = mail;
    contactNo = no;
    feedbackID = ID;
}
void User::displayDetails() {

}
void User::giveFeedback(Feedback* f) {
    f->getFeedback();
}